<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'Arrissa Data API'; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#ffffff',
                        dark: {
                            100: '#0a0a0a',
                            200: '#050505',
                            300: '#000000',
                        }
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <script src="https://unpkg.com/feather-icons"></script>
    <style>
        :root {
            --bg-primary: #0f0f0f;
            --bg-secondary: #1a1a1a;
            --bg-tertiary: #2d2d2d;
            --text-primary: #ffffff;
            --text-secondary: #a0a0a0;
            --accent: #4f46e5;
            --accent-hover: #6366f1;
            --border: #3a3a3a;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --card-bg: #1f1f1f;
            --input-bg: #262626;
            --input-border: #404040;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--bg-primary);
            transition: background-color 0.3s, color 0.3s;
            overflow: hidden;
            position: fixed;
            width: 100%;
            height: 100%;
            font-size: 16px;
        }
        body.light-theme {
            --bg-primary: #ffffff;
            --bg-secondary: #f9fafb;
            --bg-tertiary: #f3f4f6;
            --text-primary: #111827;
            --text-secondary: #6b7280;
            --border: #e5e7eb;
            --card-bg: #ffffff;
            --input-bg: #f9fafb;
            --input-border: #d1d5db;
        }
        .sidebar-link {
            transition: all 0.2s;
        }
        .sidebar-link:hover {
            background: rgba(255, 255, 255, 0.05);
        }
        .sidebar-link.active {
            background: rgba(255, 255, 255, 0.08);
        }
        .theme-toggle {
            cursor: pointer;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.2s;
        }
        .theme-toggle:hover {
            background: rgba(255, 255, 255, 0.05);
        }
        
        /* Global pill styles */
        button, .btn, input[type="submit"] {
            border-radius: 9999px !important;
        }
        input:not([type="checkbox"]):not([type="radio"]) {
            border-radius: 9999px !important;
        }
        .card, .api-card {
            border-radius: 24px !important;
        }
    </style>
</head>
<body style="background-color: var(--bg-primary);">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <aside class="w-72 flex flex-col" style="background-color: var(--bg-primary); border-right: 1px solid var(--border);">
            <!-- Logo -->
            <div class="p-7" style="border-bottom: 1px solid var(--border);">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-full flex items-center justify-center" style="background-color: var(--text-primary);">
                        <span class="font-bold text-lg" style="color: var(--bg-primary);">A</span>
                    </div>
                    <span class="font-semibold text-lg tracking-tight" style="color: var(--text-primary);">Arrissa Data API</span>
                </div>
            </div>

            <!-- Navigation -->
            <nav class="flex-1 px-4 py-3">
                <a href="/" class="sidebar-link <?php echo ($page ?? '') == 'dashboard' ? 'active' : ''; ?> flex items-center space-x-3 px-4 py-3 rounded-full mb-2" style="color: <?php echo ($page ?? '') == 'dashboard' ? 'var(--text-primary)' : 'var(--text-secondary)'; ?>;">
                    <i data-feather="grid" style="width: 20px; height: 20px;"></i>
                    <span class="text-base font-medium">Dashboard</span>
                </a>
                <a href="/market-data-api-guide" class="sidebar-link <?php echo ($page ?? '') == 'market-data-api' ? 'active' : ''; ?> flex items-center space-x-3 px-4 py-3 rounded-full mb-2" style="color: <?php echo ($page ?? '') == 'market-data-api' ? 'var(--text-primary)' : 'var(--text-secondary)'; ?>;">
                    <i data-feather="trending-up" style="width: 20px; height: 20px;"></i>
                    <span class="text-base font-medium">Market Data API Guide</span>
                </a>
            </nav>

            <!-- Settings -->
            <div class="p-4" style="border-top: 1px solid var(--border);">
                <div class="flex items-center justify-between mb-3">
                    <a href="/settings" class="sidebar-link <?php echo ($page ?? '') == 'settings' ? 'active' : ''; ?> flex items-center space-x-3 px-4 py-3 rounded-full flex-1" style="color: <?php echo ($page ?? '') == 'settings' ? 'var(--text-primary)' : 'var(--text-secondary)'; ?>;">
                        <i data-feather="settings" style="width: 20px; height: 20px;"></i>
                        <span class="text-base font-medium">Settings</span>
                    </a>
                    <div class="theme-toggle" onclick="toggleTheme()" title="Toggle theme">
                        <i data-feather="moon" id="theme-icon" style="width: 20px; height: 20px; color: var(--text-secondary);"></i>
                    </div>
                </div>
                <a href="/auth/logout" class="sidebar-link flex items-center space-x-3 px-4 py-3 rounded-full" style="color: var(--text-secondary);">
                    <i data-feather="log-out" style="width: 20px; height: 20px;"></i>
                    <span class="text-base font-medium">Logout</span>
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 overflow-y-auto" style="background-color: var(--bg-primary);">
            <div class="min-h-full">
                <?php echo $content ?? ''; ?>
            </div>
        </main>
    </div>
    <script>
        feather.replace();
        
        function toggleTheme() {
            const body = document.body;
            const themeIcon = document.getElementById('theme-icon');
            
            if (body.classList.contains('light-theme')) {
                body.classList.remove('light-theme');
                localStorage.setItem('theme', 'dark');
                // Update icon
                themeIcon.setAttribute('data-feather', 'moon');
                feather.replace();
            } else {
                body.classList.add('light-theme');
                localStorage.setItem('theme', 'light');
                // Update icon
                themeIcon.setAttribute('data-feather', 'sun');
                feather.replace();
            }
        }
        
        // Load saved theme
        document.addEventListener('DOMContentLoaded', function() {
            const savedTheme = localStorage.getItem('theme');
            const themeIcon = document.getElementById('theme-icon');
            
            if (savedTheme === 'light') {
                document.body.classList.add('light-theme');
                themeIcon.setAttribute('data-feather', 'sun');
                feather.replace();
            }
        });
    </script>
</body>
</html>
